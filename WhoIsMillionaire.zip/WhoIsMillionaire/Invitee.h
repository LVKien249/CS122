#ifndef INVITEE_H
#define INVITEE_H
#include "Person.h"
class Invitee:public Person
{
	private:
		int rightAnswer;
		int answer;
	public:
		Invitee(string n = "", int a = 0, bool g = false, string i = "", int rA = 0)
		:Person(n, a, g, i), rightAnswer(0){}
		~Invitee(){}

		string getName()
		{
			return name;
		}

		int getRightAnswer()
		{
			return rightAnswer;
		}

		int getAnswer()
		{
			return answer;
		}

		int money()
		{
			return rightAnswer*300000;
		}

		void setRightAnswer(int a)
		{
			rightAnswer = a;
		}

		void anSwer()
		{
			cout<<name<<": "<<endl;
			cout<<"Dap an cua toi la: ";
			int a; cin>>a;
			answer = a;
		}

		friend istream &operator >> (istream &in, Invitee &a)
		{
			//cout<<"nhap ten: ";
			getline(in,a.name);
			//cout<<"Nhap tuoi: ";
			in>>a.age;
			//cout<<"Nhap gioi tinh(1/nam, 0/nu): ";
			in>>a.genDer;
			//cout<<"Nhap CMTND: ";
			in>>a.identityCard;
			return in;
		}

		void print()
		{
			cout<<name<<"    "<<age<<endl;
		}
	
};

#endif