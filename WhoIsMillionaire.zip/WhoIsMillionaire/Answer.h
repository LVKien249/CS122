#ifndef ANSWER_H
#define ANSWER_H
class Answer
{
	private:
		int number;
	public:
		Answer(){}
		~Answer(){}

		void set(int a)
		{
			number = a;
		}

		int getNum()
		{
			return number;
		}
		
	
};

#endif