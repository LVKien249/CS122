#ifndef PERSON_H
#define PERSON_H
#include <iostream>
using namespace std;

class Person
{
	protected:
		string name;
		int age;
		bool genDer;
		string identityCard;
	public:
		Person(string n = "", int a = 0, bool g = false, string i = "")
		:name(n), age(a), genDer(g), identityCard(i){}
		~Person(){}
};

#endif