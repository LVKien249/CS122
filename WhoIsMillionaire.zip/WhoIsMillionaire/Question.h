#ifndef QUESTION_H
#define QUESTION_H
class Question
{
	private:
		int number1;
		int number2;
	public:
		Question(){}
		~Question(){}

		void set(int a, int b)
		{
			number1 = a;
			number2 = b;
		}

		int getNum1()
		{
			return number1;
		}

		int getNum2()
		{
			return number2;
		}
	
};

#endif