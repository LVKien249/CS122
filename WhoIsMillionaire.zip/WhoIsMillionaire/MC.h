#ifndef MC_H
#define MC_H
#include <stdlib.h>
#include <ctime>
#include <vector>
#include "Person.h"
#include "Question.h"
#include "Answer.h"
#include "Player.h"
#include "Invitee.h"
class MC:public Person
{
	private:
		int hoursWorked;
		int salaryPerHour;
		
	public:
		MC(string n = "", int a = 0, bool g = false, string i = "", int hw = 0, int sph = 0)
		:Person(n, a, g, i), hoursWorked(hw), salaryPerHour(sph){}
		~MC(){}

		string getName()
		{
			return name;
		}
		
		void readQuesTion(Question a)
		{
			cout<<"Ket qua cua phep tinh "<<a.getNum1()<<" + "<<a.getNum2()<<" la gi?"<<endl;
		}

		void talk(Player a)
		{
			cout<<"Xin moi nguoi choi ";
			a.Name();
			cout<<endl;
		}

		void readAnswer(int a)
		{
			cout<<"Dap an la: "<<a<<endl;
		}

		void checkAnswer(Player &a, int an, int ro)
		{
			if (a.getAnswer() != an)
			{
				cout<<"Nguoi choi co so bao danh: "<<a.getNumber()<<" da tra loi sai"<<endl;
				cout<<"Ban se dung cuoc choi tai day"<<endl;
				cout<<"Ban se ra ve voi so tien thuong la: "<<a.money()<<" dong"<<endl<<endl;
				a.setStatus(false);
			}
			else
			{
				cout<<"Chuc mung ban da tra loi dung"<<endl<<endl;
				a.setPoint(a.getPoint() + 100);
				a.setRound(ro);
			}	
		}

		void chooseInviteeToAnswer(Invitee &a, int an)
		{
			a.anSwer();
			if (a.getAnswer() == an)
			{
				cout<<"Chuc mung ban da tra loi dung"<<endl;
				cout<<"Ban co them mot diem thuong"<<endl<<endl;
				a.setRightAnswer(a.getRightAnswer() + 1);
			}
		}

		void print()
		{
			cout<<name<<endl;
		}

		friend istream &operator >> (istream &in, MC &a)
		{
			in.ignore();
			//cout<<"nhap ten: ";
			getline(in,a.name);
			//cout<<"Nhap tuoi: ";
			in>>a.age;
			//cout<<"Nhap gioi tinh(1/nam, 0/nu): ";
			in>>a.genDer;
			//cout<<"Nhap CMTND: ";
			in>>a.identityCard;
			return in;
		}
};

#endif