#include "Player.h"

#include "Person.h"
int main()
{
	Player a[3];
	for (int i =0 ;i<3;i++)
	{
		cin>>a[i];
		cin.ignore();
	}

	Person aa[3];
	for (int i =0 ;i<3;i++)
	{
		cin>>aa[i];
		cin.ignore();
	}
	return 0;
}