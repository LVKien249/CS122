#include "MC.h"
#include "Invitee.h"
#include "Player.h"
#include <stdlib.h>

class GameShow
{
	private:
		MC mc;
		int round;
		Invitee iv[10];
		Player pl[4];
		vector<Question> q;
		vector<int> answer;
		int live;
	public:
		GameShow(){}
		~GameShow(){}
			
		void setQuestion(vector<Question> v)
		{
			q = v;
		}
		
		void setAnswer(vector<int> v)
		{
			answer = v;
		}

		void setRound(int a)
		{
			round = a;
		}	

		void setP(MC a, Invitee b[10], Player c[4])
		{
			mc = a;
			for (int i = 0; i<10; i++)
				iv[i] = b[i];
			for (int i = 0;i<4;i++)
				pl[i] = c[i];
		}

		void Play()
		{
			int count2 = 0;
			for (int i = 0; i<round; i++)
			{
				system("clear");
				mc.readQuesTion(q[i]);;
				int count1 = 0;
				for (int m = 0; m < 4; m++)
				{
					if (pl[m].getStatus() == true)
					{
						mc.talk(pl[m]);
						pl[m].anSwer();
						mc.checkAnswer(pl[m], answer[i], i+1);
						count1++;
					}
				}
				live = count1;
				for (int j = 0; j<4; j++)
				{
					if (pl[j].getStatus() == 1)
						count2++;
				}

				if (count2 < live)
				{
					int c = rand()%9;
					mc.chooseInviteeToAnswer(iv[c], answer[i]);	
				}

				if (live == 1 && i == round -1)
				{
					int nb;
					cout<<"Chuc mung nguoi choi ";
					for (int k = 0;k<4;i++)
						if(pl[k].getStatus())
						{
							pl[k].Name();
							nb = k;
							break;
						}
					cout<<"da danh chien thang ban se ra ve voi phan thuong tri gia: "<<pl[nb].money()<<" dong"<<endl;

				}

				if (i == round - 1)
				{
					cout<<"Chuong trinh se ket thuc tai day"<<endl<<endl;
					cout<<"Cac khach moi sau se nhan duoc phan thuong la: "<<endl;
					for (int ii = 0; ii<10; ii++)
					{
						if (iv[ii].getRightAnswer()> 0)
							cout<<iv[ii].getName()<<" nhan duoc "<<iv[ii].money()<<" dong"<<endl;
					}
					break;
				}

				cout<<"Ket thuc round "<<i+1<<endl;
				cout<<"Nhap ki tu bat ki de tiep tuc round tiep theo"<<endl;
				string aa;cin>>aa;

			}

		}

		void infoGame()
		{
			cout<<"MC: ";mc.print();
			
			cout<<"Thong tin cac nguoi choi: "<<endl;
			for (int i = 0 ;i<4; i++)
				pl[i].print();
			
			cout<<endl;
			cout<<"Thong tin cac khach moi: "<<endl;
			for (int i = 0 ;i<10; i++)
				iv[i].print();
		}
	

};