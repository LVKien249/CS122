#ifndef PLAYER_H
#define PLAYER_H
#include "Person.h"
class Player:public Person
{
	private:
		string number;
		bool status;
		int point;
		int round;
	public:
		Player(string n = "", int a = 0, bool g = false, string i = "", string nB = "", bool st = true, int p = 0, int r = 0)
		:Person(n, a, g, i), number(nB), status(st), point(p), round(r){}

		~Player(){}
	
};

#endif