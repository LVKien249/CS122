#ifndef PLAYER_H
#define PLAYER_H
#include "Person.h"
class Player:public Person
{
	private:
		string number;
		bool status;
		int point;
		int round;
		int answer;
	public:
		Player(string n = "", int a = 0, bool g = false, string i = "", string nB = "", bool st = true, int p = 0, int r = 0)
		:Person(n, a, g, i), number(nB), status(st), round(0), point(0){}
		~Player(){}

		string getNumber()
		{
			return number;
		}

		bool getStatus()
		{
			return status;
		}

		int getPoint()
		{
			return point;
		}

		int getRound()
		{
			return round;
		}

		void setStatus(bool a)
		{
			status = a;
		}

		void setPoint(int a)
		{
			point = a;
		}

		void setRound(int a)
		{
			round = a;
		}

		int getAnswer()
		{
			return answer;
		}

		int money()
		{
			return round * point * 100000;
		}

		void anSwer()
		{
			cout<<name<<": "<<endl;
			cout<<"Dap an cua toi la: ";
			int a; cin>>a;
			answer = a;
			cout<<endl;
		}

		void print()
		{
			cout<<name<<"    "<<age<<endl;
		}

		void Name()
		{
			cout<<name<<endl;
		}

		friend istream &operator >> (istream &in, Player &a)
		{
			//cout<<"Nhap so bao danh: ";
			in>>a.number;
			in.ignore();
			//cout<<"nhap ten: ";
			getline(in,a.name);
			//cout<<"Nhap tuoi: ";
			in>>a.age;
			//cout<<"Nhap gioi tinh(1/nam, 0/nu): ";
			in>>a.genDer;
			//cout<<"Nhap CMTND: ";
			in>>a.identityCard;
			return in;
		}
	
};

#endif