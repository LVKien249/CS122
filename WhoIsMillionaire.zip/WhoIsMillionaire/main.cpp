#include "GameShow.h"
#include "Person.h"
#include <fstream>
int main()
{
	GameShow game;
	vector<Question> q;
	vector<int> an;

	cout<<"Nhap so round: ";
	int n;cin>>n;
	game.setRound(n);

	Question Q;
	srand(time(NULL));
	for(int i = 0; i<n; i++)
	{
		int a = rand()%1000;
		int b = rand()%1000;
		Q.set(a,b);
		q.push_back(Q);
		an.push_back(a+b);
	}

	game.setQuestion(q);
	game.setAnswer(an);

	ifstream fin("info.txt");

	MC mc;
	//cout<<"Nhap thong tin cho MC"<<endl;
	fin.ignore(0);
	fin>>mc;

	//cout<<"Nhap thong tin cho nguoi choi"<<endl;
	Player pl[4];
	for (int i = 0 ;i<4; i++)
	{
		fin>>pl[i];
		fin.ignore();
	}

	//cout<<"Nhap thong tin cho khach moi"<<endl;
	Invitee iv[10];
	for (int i = 0 ;i<10; i++)
	{
		fin>>iv[i];
		fin.ignore();
	}

	game.setP(mc, iv, pl);

	//cout<<endl;
	//game.infoGame();

	game.Play();

	return 0;
}