#ifndef CUONTHIT_H
#define CUONTHIT_H

#include "BanhCuon.h"
class CuonThit:public BanhCuon
{
	protected:
		int giaThit;
		int khoiLuongThit;
	public:
		CuonThit(int, int, int, int, int);
		~CuonThit();

		virtual int thanhTien()
		{
			return ( (giaThit*khoiLuongThit) + (giaVo*khoiluongVo) )*soluong;	
		}
		
		friend istream &operator >> (istream &, CuonThit &);

		void setgiaThanh(int, int, int, int);

		virtual void printInfo();
};

CuonThit::CuonThit(int gv = 100, int sl = 0, int klv = 0, int gt = 200, int klt = 0)
		:BanhCuon(gv,sl), giaThit(gt), khoiLuongThit(klt){} 
CuonThit::~CuonThit(){}

istream &operator >> (istream &in, CuonThit &a)
{
	cout<<"Nhap so luong: ";
	in>>a.soluong;
	return in;
}

void CuonThit::setgiaThanh(int a, int b, int c, int d)
{
	giaVo = a;
	khoiluongVo = b;
	giaThit = c;
	khoiLuongThit = d;
}

void CuonThit::printInfo()
{
	cout<<left<<setw(8)<<soluong<<endl;
}

#endif