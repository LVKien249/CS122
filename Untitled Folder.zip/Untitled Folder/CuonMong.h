#ifndef CUONMONG_H
#define CUONMONG_H
#include "BanhCuon.h"

class CuonMong:public BanhCuon
{
	private:
		int giaHanh;
		int khoiLuongHanh;
	public:
		CuonMong(int, int, int, int, int);
		~CuonMong();

		virtual int thanhTien()
		{
			return ( (giaHanh * khoiLuongHanh) + (giaVo*khoiluongVo) ) *soluong;	
		}

		void setgiaThanh(int, int, int, int);
		
		friend istream &operator >> (istream &, CuonMong &);

		virtual void printInfo();
};

CuonMong::CuonMong(int gv = 100, int sl = 0, int klv = 0, int gn = 100, int klh = 0)
		:BanhCuon(gv,sl,klv), giaHanh(gn), khoiLuongHanh(klh){} 
CuonMong::~CuonMong(){}

istream &operator >> (istream &in, CuonMong &a)
{
	cout<<"Nhap so luong: ";
	in>>a.soluong;
	return in;
}

void CuonMong::setgiaThanh(int a, int b, int c, int d)
{
	giaVo = a;
	khoiluongVo = b;
	giaHanh = c;
	khoiLuongHanh = d;
}

void CuonMong::printInfo()
{
	cout<<left<<setw(8)<<soluong<<endl;
}

#endif