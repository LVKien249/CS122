#ifndef BANHCUON_H
#define BANHCUON_H
#include <iostream>
#include <iomanip>
using namespace std;
class BanhCuon
{
	protected:
		int giaVo;
		int soluong;
		int khoiluongVo;
	public:
		BanhCuon(int, int, int);
		~BanhCuon();
		virtual int thanhTien() = 0;
		virtual void printInfo() = 0;
		void setgiaThanh(int, int);
		
		
};

BanhCuon::BanhCuon(int gv = 100, int sl = 0, int klv = 0):giaVo(gv), soluong(sl), khoiluongVo(klv){}
BanhCuon::~BanhCuon(){}

void BanhCuon::setgiaThanh(int a, int b)
{
	giaVo = a;
	khoiluongVo = b;
}

#endif