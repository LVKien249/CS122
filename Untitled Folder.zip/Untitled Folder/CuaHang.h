#ifndef CUAHANG_H
#define CUAHANG_H
#include <vector>
#include "DonHang.h"
class CuaHang
{
	private:

		vector <DonHang> dh;
		int doanhThu;
		int tienNhuong;
	public:
		CuaHang();
		~CuaHang();

		void addDonHang(DonHang a)
		{
			dh.push_back(a);
		}
		
		void show()
		{

			int sum = 0;
			for (int i = 0; i<dh.size(); i++)
			{
				sum += dh[i].getTongTien(); 
			}
			doanhThu = sum;
			tienNhuong = doanhThu/10;
			cout<<"Doanh thu cua cua hang nay la: "<<doanhThu<<endl;
			cout<<"So tien nhuong phai tra la: "<<tienNhuong<<endl;
		}


	
};
CuaHang::CuaHang(){}
CuaHang::~CuaHang(){}

#endif