#ifndef DONHANG_H
#define DONHANG_H
#include "BanhCuon.h"
#include "CuonChay.h"
#include "CuonMong.h"
#include "CuonThit.h"
#include "CuonDB.h"
#include "KhachHang.h"
#include <vector>
#include <stdlib.h>
#include <iomanip>

int chon();
class DonHang
{
	private:
		KhachHang kh;
		vector <BanhCuon*> bc;
		vector <string> t;
		int tongTien;
		int idBill;
	public:
		static int ID;
		DonHang();
		~DonHang();

		int getTongTien()
		{
			return tongTien;
		}

		void Bill(int, int, int, int, int, int, int, int, int, int);
		void print();
};

DonHang::DonHang()
{
	idBill = ID++;
}
DonHang::~DonHang(){}

int DonHang:: ID = 0;

int chon()
{
	cout<<"1. Banh cuon chay"<<endl;
	cout<<"2. Banh cuon mong"<<endl;
	cout<<"3. Banh cuon thit"<<endl;
	cout<<"4. Banh cuon dac biet"<<endl;
	cout<<"0. Exit"<<endl;
	cout<<"Nhap lua chon: ";
	int n;cin>>n;
	return n;
}

void DonHang::Bill(int a, int b, int c, int d, int e, int f,int g, int h, int j,int k)
{
	vector <BanhCuon*> buy;
	vector <string> ten;
	KhachHang kk;
	cout<<"Nhap thong tin khach hang: "<<endl;
	cin>>kk;
	kh = kk;
	int op = 1, sum = 0;
	while (op != 0)
	{
		system("clear");
		op = chon();
		if (op == 1)
		{
			CuonChay *aa = new CuonChay();
			cin>>*aa;
			aa ->setgiaThanh(a,b,c,d);
			buy.push_back(aa);
			ten.push_back("Banh Cuon Chay");
			sum += aa->thanhTien();	
		}

		else if (op == 2)
		{
			CuonMong *aa = new CuonMong();
			cin>>*aa;
			aa ->setgiaThanh(a,b,e,f);
			buy.push_back(aa);
			ten.push_back("Banh Cuon Mong");
			sum += aa->thanhTien();
		}

		else if (op == 3)
		{
			CuonThit *aa = new CuonThit();
			cin>>*aa;
			aa ->setgiaThanh(a,b,g,h);
			buy.push_back(aa);
			ten.push_back("Banh Cuon Thit");
			sum += aa->thanhTien();
		}

		else if (op == 4)
		{
			CuonDB *aa = new CuonDB();
			cin>>*aa;
			aa ->setgiaThanh(a,b,g,h,j,k);
			buy.push_back(aa);
			ten.push_back("Banh Cuon Dac Biet");
			sum += aa->thanhTien();
		}

		else
			break;

		cout<<"Nhap bat ki de tiep tuc: ";
		string a;cin>>a;
	}
	bc = buy;
	t = ten;
	tongTien = sum;
}

void DonHang::print()
{
	cout<<"BILL "<<idBill<<":"<<endl;
	cout<<"Thong tin khach hang: "<<endl;
	kh.printInfor();
	cout<<endl;
	cout<<"Cac san pham da mua: "<<endl;
	for (int i = 0; i<bc.size(); i++)
	{
		cout<<i+1<<". "<<t[i]<<" ";
		bc[i] ->printInfo();
	}	

	cout<<endl;
	cout<<"Tong tien: "<<tongTien<<endl;
}

#endif