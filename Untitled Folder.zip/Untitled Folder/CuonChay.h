#ifndef CUONCHAY_H
#define CUONCHAY_H

#include "BanhCuon.h"

class CuonChay:public BanhCuon
{
	private:
		int giaNhan;
		int khoiLuongNhan;
	public:
		CuonChay(int, int, int, int, int);
		~CuonChay();
		virtual int thanhTien()
		{
			return ( (giaNhan * khoiLuongNhan) + (giaVo*khoiluongVo) )*soluong ;	
		}

		friend istream &operator >> (istream &, CuonChay &);

		void setgiaThanh(int, int, int, int);

		virtual void printInfo();
	
};

CuonChay::CuonChay(int gv = 100, int sl = 0, int klv = 0, int gn = 150, int kln = 0)
		:BanhCuon(gv,sl,klv), giaNhan(gn), khoiLuongNhan(kln){} 
CuonChay::~CuonChay(){}

istream &operator >> (istream &in, CuonChay &a)
{
	cout<<"Nhap so luong: ";
	in>>a.soluong;
	return in;
}

void CuonChay::setgiaThanh(int a, int b, int c, int d)
{
	giaVo = a;
	khoiluongVo = b;
	giaNhan = c;
	khoiLuongNhan = d;
}

void CuonChay::printInfo()
{
	cout<<left<<setw(8)<<soluong<<endl;
}

#endif