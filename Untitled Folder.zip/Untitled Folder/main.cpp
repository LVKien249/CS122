#include <iostream>
#include "CuaHang.h"
using namespace std;
int main()
{
	CuaHang aa;
	int a,b,c,d,e,f,g,h,j,k;
	cout<<"Nhap gia vo: "; cin>>a;
	cout<<"Nhap khoi luong vo: "; cin>>b;

	cout<<"Nhap gia nhan: "; cin>>e;
	cout<<"Nhap khoi luong nhan: "; cin>>f;

	cout<<"Nhap gia hanh: "; cin>>c;
	cout<<"Nhap khoi luong hanh: "; cin>>d;

	cout<<"Nhap gia thit: "; cin>>g;
	cout<<"Nhap khoi luong thit: "; cin>>h;

	cout<<"Nhap gia thit cc: "; cin>>j;
	cout<<"Nhap khoi luong thit cc: "; cin>>k;

	DonHang bb;
	bb.Bill(a,b,c,d,e,f,g,h,j,k);
	bb.print();

	aa.addDonHang(bb);

	cout<<endl;
	aa.show();
	return 0;
}