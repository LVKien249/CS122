#ifndef CUONDB_H
#define CUONDB_H
#include "CuonThit.h"

class CuonDB:public CuonThit
{
	private:
		int giaThitCC;
		int khoiluongThitCC;
	public:
		CuonDB(int, int, int, int, int, int, int);
		~CuonDB();

		virtual int thanhTien()
		{
			return ( (giaThit*khoiLuongThit) + (giaThitCC*khoiluongThitCC) + (giaVo*khoiluongVo) )*soluong;	
		}

		void setgiaThanh(int, int, int, int, int, int);

		friend istream &operator >> (istream &, CuonDB &);
	
		virtual void printInfo();
};

CuonDB::CuonDB(int gv = 100, int sl = 0,int klv = 0, int gt = 200, int klt = 0, int gtcc = 300, int sltcc = 0)
		:CuonThit(gv, sl, klv, gt, klt), giaThitCC(gtcc), khoiluongThitCC(sltcc){}
CuonDB::~CuonDB(){}

istream &operator >> (istream &in, CuonDB &a)
{
	cout<<"Nhap so luong: ";
	in>>a.soluong;
	return in;
}

void CuonDB::setgiaThanh(int a, int b, int c, int d,int e,int f)
{
	giaVo = a;
	khoiluongVo = b;
	giaThit = c;
	khoiLuongThit = d;
	giaThitCC = e;
	khoiluongThitCC = f;
}

void CuonDB::printInfo()
{
	cout<<left<<setw(8)<<soluong<<endl;
}

#endif