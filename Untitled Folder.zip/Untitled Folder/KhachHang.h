#ifndef KHACHHANG_H
#define KHACHHANG_H
#include <iostream>
#include <iomanip>
using namespace std;

class KhachHang
{
	private:
		string name;
		string phoneNumber;
		string address;
	public:
		KhachHang(string, string, string);
		~KhachHang();
		void printInfor();

		friend istream &operator >> (istream &, KhachHang &);
	
};

KhachHang::KhachHang(string n = "", string pN = "", string ad = "")
	:name(n), phoneNumber(pN), address(ad){}

KhachHang::~KhachHang(){}


void KhachHang::printInfor()
{
	cout<<"Name: "<<name<<"         "<<"SDT: "<<phoneNumber<<endl;
	cout<<"Address: "<<address<<endl;
}

istream & operator >> (istream &in, KhachHang &a)
{
	in.ignore();
	cout<<"Nhap ten: ";
	getline(in, a.name);
	cout<<"Nhap sdt: ";
	in>>a.phoneNumber;
	cout<<"Nhap dia chi: ";
	in.ignore();
	getline(in, a.address);
	return in;
}

#endif