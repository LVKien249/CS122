#include <iostream>
using namespace std;
class Book
{
	protected:
		string name;
		int nsx;
		double hs;
	public:
		Book(){}
		Book(string a, int b, double c):name(a),nsx(b),hs(c){}
		~Book(){}

		void setName(string a)
		{
			name = a;
		}

		void setNsx(int a)
		{
			nsx = a;
		}

		void setHs(double a)
		{
			hs = a;
		}

		string getName()
		{
			return name;
		}

		int getNsx()
		{
			return nsx;
		}

		double getHs()
		{
			return hs;
		}

		virtual double TinhTien()=0;
		virtual void Print()=0;
};

class BookTH: public Book
{
	private:
		double GN;
	public:
		BookTH(){}
		BookTH(string a,int b,double c,double d):Book(a,b,c),GN(d){}

		void setGN(double a)
		{
			GN = a;
		}

		double getGN()
		{
			return GN;
		}

		double TinhTien()
		{
			return getHs()*GN;
		}

		void Print()
		{
			cout<<name<<" "<<nsx<<" "<<hs<<" "<<GN<<endl;
		}

		friend istream & operator >> (istream &in,BookTH & a)
		{
			cout<<"nhập tên sách tin học: ";
			in.ignore();
			getline(in,a.name);
			cout<<"nhập ngày sản xuất: ";
			in>>a.nsx;
			cout<<"nhập hệ số: ";
			in>>a.hs;
			cout<<"giá nhập: ";
			in>>a.GN;
			return in;
		}
};

class BookKT: public Book
{
	private:
		double GN;
		double CK;
	public:
		BookKT(){}
		BookKT(string a, int b, double c, double d, double e):
		Book(a,b,c),GN(d),CK(e){}

		double TinhTien()
		{
			return GN * getHs() - CK;
		}

		void Print()
		{
			cout<<name<<" "<<nsx<<" "<<hs<<" "<<GN<<" "<<CK<<endl;	
		}

		friend istream & operator >> (istream &in,BookKT & a)
		{
			cout<<"nhập tên sách kinh tế: ";
			in.ignore();
			getline(in,a.name);
			cout<<"nhập ngày sản xuất: ";
			in>>a.nsx;
			cout<<"nhập hệ số: ";
			in>>a.hs;
			cout<<"giá nhập: ";
			in>>a.GN;
			cout<<"nhập chiết khấu: ";
			in>>a.CK;
			return in;
		}

};

void Main()
{
	Book * a[6];
	for (int i = 0 ; i<1;i++)
	{
		if (i % 2 ==0)
		{
			BookKT *b = new BookKT();
			cin>>*b;
			a[i] = b;
		}
		else
		{
			BookTH *c = new BookTH();
			cin>>*c;
			a[i] = c;
		}
	}

	double max = 0;
	for (int i =0  ;i<1;i++)
		if (max < a[i]->TinhTien())
			max = a[i] ->TinhTien();

	for (int i = 0;i<1;i++)
		if (a[i] ->TinhTien() == max)
			a[i] ->Print();

	for (int i = 0;i<1;i++)
		a[i]->Print();

}
