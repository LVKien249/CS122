#include <iostream>
#include <fstream>
using namespace std;

class Date
{
	private:
		int d;
		int m;
		int y;
	public:
		Date(){}
		friend istream & operator >> (istream &in, Date &a)
		{
			cout<<"nhập ngày tháng năm sinh: ";
			in>>a.d>>a.m>>a.y;
			return in;
		}

		friend ostream & operator << (ostream &out, Date a)
		{
			out<<a.d<<"/"<<a.m<<"/"<<a.y<<endl;
			return out;
		}

};

class NhanVien
{
	protected:
		string name;
		Date d;
		string ID;
	public:
		NhanVien(){}
		NhanVien(string a, Date b, string c):name(a),d(b),ID(c){}
		~NhanVien(){}
		virtual double TinhLuong() = 0;
		virtual void Print() = 0;
		virtual void File() = 0;
};

class CanBo: public NhanVien
{
	private:
		string Department;
		double hs;
		int pc;
	public:
		CanBo(){}
		CanBo(string a, Date b, string c, string d, double e, int f):
		NhanVien(a,b,c),Department(d),hs(e),pc(f){}
		~CanBo(){}

		double TinhLuong()
		{
			return hs*1500000+pc;
		}

		friend istream & operator >> (istream &in, CanBo &a)
		{
			cout<<"Nhập họ và tên: ";
			in.ignore();
			getline(in,a.name);
			in>>a.d;
			cout<<"Nhập chứng minh thư: ";
			in>>a.ID;
			cout<<"Nhập phòng ban: ";
			in.ignore();
			getline(in,a.Department);
			while (a.hs < 1.8 || a.hs > 4.95)
			{
				cout<<"Nhập hệ số: ";
				in>>a.hs;
				if (a.hs <1.8 || a.hs > 4.95)
				{
					cout<<"Hệ số lương nhập chưa hợp lệ"<<endl;
					cout<<"Mời bạn nhập lại"<<endl;
				}
			}
			cout<<"Nhập phụ cấp: ";
			in>>a.pc;
			return in;
		}

		void Print()
		{
			cout<<name<<" "<<d<<endl;
			cout<<ID<<" "<<Department<<endl;
			cout<<hs<<" "<<pc<<endl;
		}

		void File()
		{
			ofstream fout("canbo.txt");
			fout<<name<<" "<<d<<endl;
			fout<<ID<<" "<<Department<<endl;
			fout<<hs<<" "<<pc<<endl;	
		}

};

class GiaoVien: public NhanVien
{
	private:
		string Dp;
		double hsl;
		int td;
	public:
		GiaoVien(){}
		GiaoVien(string a, Date b, string c, string d, double e, int f):
		NhanVien(a,b,c),Dp(d),hsl(e),td(f){	}
		~GiaoVien(){}

		friend istream & operator >> (istream &in, GiaoVien &a)
		{
			cout<<"Nhập họ và tên: ";
			in.ignore();
			getline(in,a.name);
			in>>a.d;
			cout<<"Nhập chứng minh thư: ";
			in>>a.ID;
			cout<<"Nhập khoa: ";
			in.ignore();
			getline(in,a.Dp);
			cout<<"Nhập hệ số lương: ";
			in>>a.hsl;
			cout<<"Nhập tiền dậy: ";
			in>>a.td;
			return in;
		}

		void Print()
		{
			cout<<name<<" "<<d<<endl;
			cout<<ID<<" "<<Dp<<endl;
			cout<<hsl<<" "<<td<<endl;	
		}

		void File(){}

		double TinhLuong()
		{
			return hsl*1500000+td;
		}
};

void Main()
{
	NhanVien *a[1000];
	ofstream fout("canbo.txt");
	int option,i=0;
	do
	{
		cout<<"1. Thêm cán bộ"<<endl;
		cout<<"2. Thêm giáo viên"<<endl;
		cout<<"0. Exit"<<endl;
		cin>>option;
		if (option == 1)
		{
			CanBo *c = new CanBo();
			cin>>*c;
			a[i++] = c;
			fout<<c<<endl;
		}
		else if (option == 2)
		{
			GiaoVien *b = new GiaoVien();
			cin>>*b;
			a[i++] = b;
		}

	}
	while(option != 0);
	int min = a[0] -> TinhLuong();
	for (int n = 0;n < i;n++)
		if (min > a[n] -> TinhLuong())
			min = a[0] -> TinhLuong();


	cout<<"Những cán bộ có lương thấp nhất là: "<<endl;
	for (int j = 0;j<i; j++)
		if (a[j] -> TinhLuong() == min)
			a[j] ->Print();

	for (int j = 0 ;j<i;j++)
		a[j] ->File();
}
