#include <iostream>
#include <iomanip>
#include <fstream>
using namespace std;

class Employee
{
	private:
		string name;
		int ns;
		string id;
		double luong;
		int snc;
		string dvct;
	public:
		Employee(){}

		void setName(string a)
		{
			name = a;
		}

		void setNs(int a)
		{
			ns = a;
		}

		void setID(string a)
		{
			id = a;
		}

		void setLuong(double a)
		{
			luong = a;
		}

		void setSnc(int a)
		{
			snc = a;
		}

		void setDvct(string a)
		{
			dvct = a;
		}

		string getName()
		{
			return name;
		}

		int getNs()
		{
			return ns;
		}

		string getID()
		{
			return id;
		}

		double getLuong()
		{
			return luong;
		}

		int getSnc()
		{
			return snc;
		}

		string getDvct()
		{
			return dvct;
		}

		friend istream &operator >> (istream &in, Employee &a)
		{
				
			getline(in,a.name);
			//cout<<"Nhập năm sinh:";
			in>>a.ns;
			//cout<<"Nhập chứng minh thư: ";
			in>>a.id;
			//cout<<"Nhập lương: ";
			in>>a.luong;
			do
			{
				//cout<<"Nhập số ngày công: ";
				in>>a.snc;
				if (a.snc > 26)
				{
				//	cout<<"Không hợp lệ"<<endl;
				//	cout<<"Mời bạn nhập lại"<<endl;
				}
			}while(a.snc > 26);
			//cout<<"Nhập đơn vị công tác: ";
			in.ignore();
			getline(in,a.dvct);
			return in;
		}

		double TinhLuong()
		{
			return (luong *snc)/26;
		}

		void HienThi()
		{
			cout<<left<<setw(20)<<name<<left<<setw(9)<<ns
			<<left<<setw(10)<<luong<<left<<setw(20)<<dvct<<endl;
		}

		void File()
		{
			ofstream fout("emp.txt");
			fout<<name<<endl;
			fout<<ns<<endl;
			fout<<id<<endl;
			fout<<luong<<endl;
			fout<<snc<<endl;
			fout<<dvct<<endl;
			fout.close();
		}
};

void Main()
{
	Employee a[100],b[100];
	for (int i = 0;i<1;i++)
	{
		cin>>a[i];
		a[i].File();
	}

	ifstream fin("emp.txt");
	for (int i = 0;i<1;i++)
		fin>>b[i];
	cout<<left<<setw(20)<<"Họ và tên"<<left<<setw(9)<<"Năm sinh"
	<<left<<setw(10)<<"Lương"<<left<<setw(20)<<"Đơn vị"<<endl;
	for(int i = 0;i<1;i++)
		b[i].HienThi();

	int max = b[0].TinhLuong(),min = b[0].TinhLuong();
	for (int i = 0;i<1;i++)
	{
		if(max < b[i].TinhLuong())
			max = b[i].TinhLuong();
		if (min > b[i].TinhLuong())
			min = b[i].TinhLuong();
	}
	cout<<"Nhân viên có lương cao nhất là:"<<endl;
;	for (int i = 0;i<1;i++)
		if(b[i].TinhLuong() == max)
			b[i].HienThi();
	cout<<"Nhân viên có lương thấp nhất là:"<<endl;
	for (int i = 0;i<1;i++)
		if(b[i].TinhLuong() == min)
			b[i].HienThi();

	for (int i = 0 ;i<1;i++)
	{
		int max1 = 0;
		for (int j = i;j<1;j++)
			if (b[i].getDvct() == b[j].getDvct() && b[j].TinhLuong() > max1)
				max1 = b[j].TinhLuong();
		cout<<"Nhân viên có lương cao nhất của đơn vị "<<b[i].getDvct()<<"là:"<<endl;
		for (int j = i;j<1;j++)
			if (b[i].getDvct() == b[j].getDvct() && b[j].TinhLuong() == max1)
				b[j].HienThi();
	}

}
