#include <iostream>
using namespace std;
class PhanSo
{
	protected:
		int t;
		int m;
	public:
		PhanSo(){}
		PhanSo(int a,int b):t(a),m(b){}
		void SetTuSo(int a)
		{
			t = a;
		}

		void SetMauSo(int a)
		{
			m = a;
		}

		int GetTS()
		{
			return t;
		}

		int GetMS()
		{
			return m;
		}

		friend bool operator > (PhanSo a, PhanSo b)
		{
			return (a.t * b.m > b.t*a.m);
		}

		void Print()
		{
			cout<<t<<"/"<<m<<endl;
		}
};

class HonSo: public PhanSo
{
	private:
		int h;
	public:
		HonSo()
		{
			t = 0;
			m = 1;
			h = 0;
		}
		HonSo(int a,int b, int c):h(a),PhanSo(b,c){}
		friend HonSo operator + (PhanSo a, HonSo c)
		{
			HonSo b;
			b.h = 0;
			b.t = (c.h*c.m+c.t)*a.GetMS() + a.GetTS()*c.m;
			b.m = c.m * a.GetMS();
			return b;
		}

		void Print()
		{
			int a = t,b = m;
			 while(b != 0)
			 {
			 	int c = a % b;
			 	a = b;
			 	b = c;
			 }

			 int ucln = a;
			 t = t/ucln;
			 m = m/ucln;

			if(h == 0 && m == 1)
				cout<<t<<endl;
			else if (h == 0)
				cout<<t<<"/"<<m<<endl;

		}
};