#include <iostream>
using namespace std;

class So
{
	public:
		virtual double TinhBinhPhuong()=0;
		virtual double TinhLapPhuong()=0;
		virtual void Print()=0;
};

class SoNguyen: public So
{
	private:
		int sn;
	public:
		SoNguyen(){}
		SoNguyen(int a):sn(a){}
		void setSn(int a)
		{
			sn = a;
		}

		int getSn()
		{
			return sn;
		}

		double TinhLapPhuong()
		{
			return sn*sn*sn;
		}

		double TinhBinhPhuong()
		{
			return sn*sn;
		}

		void Print()
		{
			cout<<sn<<endl;
		}

		friend istream &operator >> (istream &in, SoNguyen &a)
		{
			in>>a.sn;
			return in;
		}

};

class PhanSo: public So
{
	private:
		int t;
		int m;
	public:
		PhanSo(){}
		PhanSo(int a, int b):t(a),m(b){}
		void setTS(int a)
		{
			t = a;
		}

		void setMS(int a)
		{
			m = a;
		}

		int getTS()
		{
			return t;
		}

		int getMS()
		{
			return m;
		}

		double TinhBinhPhuong()
		{
			return (t*t)/(m*m);
		}

		double TinhLapPhuong()
		{
			return (t*t*t)/(m*m*m);
		}

		void Print()
		{
			cout<<t<<"/"<<m<<endl;
		}

		friend istream &operator >> (istream &in, PhanSo &a)
		{
			in>>a.t>>a.m;
			return in;
		}
};

void Main()
{
	So *a[6];
	for(int i = 0;i<6;i++)
	{
		if (i%2 ==0)
		{
			SoNguyen *b = new SoNguyen();
			cin>>*b;
			a[i] = b;
		}
		else
		{
			PhanSo *c = new PhanSo();
			cin>>*c;
			a[i] = c;
		}
	}

	int max = a[0]->TinhBinhPhuong();
	for (int i = 1;i<6;i++)
		if(max < a[i] ->TinhBinhPhuong())
			max = a[i] ->TinhBinhPhuong();
	cout<<"Các số có giá trị bình phương lớn nhất là: ";
	for (int i = 0;i<6;i++)
		if(a[i] ->TinhBinhPhuong() == max)
			a[i] ->Print();

	cout<<"Các số trong mảng là: ";
	for (int i = 0;i<6;i++)
		a[i] ->Print();
}
